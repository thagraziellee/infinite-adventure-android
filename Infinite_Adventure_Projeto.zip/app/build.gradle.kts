plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.infiniteadventure.game"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.infiniteadventure.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "0.2.1"
    }
}
