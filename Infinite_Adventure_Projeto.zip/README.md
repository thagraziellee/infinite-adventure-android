# INFINITE ADVENTURE — projeto Android

Este é o projeto-fonte Android do jogo. O aplicativo abre `app/src/main/assets/index.html` em uma WebView, em tela cheia e orientação vertical.

## Gerar o APK automaticamente pelo GitHub

1. Crie um repositório vazio no GitHub.
2. Envie **o conteúdo desta pasta** para a raiz do repositório (as pastas `app` e `.github` devem aparecer diretamente na página inicial do repositório; não deixe tudo dentro de outra pasta).
3. Abra a aba **Actions**. Se aparecer uma solicitação para habilitar workflows, habilite-a.
4. Escolha **Build Android APK** e toque em **Run workflow**. Também será iniciado automaticamente quando houver um push para `main` ou `master`.
5. Quando a execução terminar com sucesso, abra a execução e baixe o artefato `INFINITE_ADVENTURE-debug-apk` na seção **Artifacts**.
6. Extraia o ZIP baixado e instale `app-debug.apk` no Android. Se o celular perguntar, autorize a instalação pelo navegador ou gerenciador de arquivos usado.

## Gerar pelo Android Studio

1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle e a instalação dos componentes solicitados.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O arquivo estará em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações importantes

- Este pacote contém o código-fonte; não é um APK compilado.
- O jogo tenta carregar Three.js pela CDN jsDelivr e usa unpkg como alternativa automática. É necessária conexão com a internet para carregar o motor 3D.
- O WebView mantém o JavaScript e o armazenamento local do jogo habilitados, mas restringe o acesso de páginas locais a outros arquivos do aparelho.
- Ao colocar o aplicativo em segundo plano, a partida é pausada automaticamente; ao voltar, ela pode continuar sem perder o ritmo do jogo.
- A interface respeita as áreas seguras de celulares com recortes de câmera e barras de sistema, evitando que os botões fiquem escondidos.
- Versão do aplicativo: 0.2.1 (compilação de testes).
- O APK do workflow é de depuração, adequado para testes, mas não está assinado para publicação na Play Store.
